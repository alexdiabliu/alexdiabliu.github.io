import { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { StarField } from '../components/StarField';
import { SectionContainer } from '../components/SectionContainer';
import { ProjectCarousel } from '../components/ProjectCarousel';
import { CursorTrail } from '../components/CursorTrail';

interface Project {
  title: string;
  description: string;
  tags: string[];
  year?: string;
  featured?: boolean;
}

const projectData: Record<string, Project & { fullDescription: string; challenge: string; solution: string; results: string[]; images: string[] }> = {
  'amd-gpu-validation': {
    title: 'GPU Validation Engineering',
    description: 'Developed automated virtualization test cases for MI300 Data Centre chip with machine learning integration.',
    tags: ['Python', 'Linux', 'Virtualization', 'Automation'],
    year: '2023',
    featured: true,
    fullDescription: 'As a GPU Validation Engineer at AMD, I developed customizable automated virtualization test cases for the MI300 Data Centre chip. This role involved optimizing test execution and automating the implementation of machine learning models on virtual machines using Docker.',
    challenge: 'Creating automated test cases that could validate complex GPU virtualization scenarios while integrating machine learning workloads in a scalable, reproducible manner.',
    solution: 'Developed Python-based automation framework with Linux and virtualization technologies. Implemented containerized ML model deployment using Docker, enabling consistent testing across different virtualization environments.',
    results: [
      'Successfully automated test case execution for MI300 chip validation',
      'Reduced testing time through optimized execution features',
      'Integrated ML model training scripts on virtual machines',
      'Improved test reproducibility using Docker containerization',
    ],
    images: [
      'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&h=800&fit=crop',
      'https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=1200&h=800&fit=crop',
    ],
  },
  'drone-visualization': {
    title: '3D Drone Data Visualization',
    description: 'Created dashboard-style program with 3D visualization of drone data for effective analysis.',
    tags: ['Python', 'Data-Viz', '3D'],
    year: '2023',
    fullDescription: 'As a Data Visualization Engineer at Hermes Aerospace Corp., I utilized Python to retrieve, clean, and efficiently segment raw drone data. I created a powerful dashboard-style program that presented a 3D visualization of the retrieved data, providing valuable insights for stakeholders.',
    challenge: 'Transforming raw, unstructured drone data into meaningful 3D visualizations that could be easily understood by non-technical stakeholders.',
    solution: 'Developed a comprehensive Python pipeline for data retrieval and cleaning, followed by a custom 3D visualization dashboard that allowed interactive exploration of complex datasets.',
    results: [
      'Successfully processed and visualized large volumes of drone data',
      'Enabled stakeholders to understand complex 3D flight patterns',
      'Improved decision-making through clear data presentation',
      'Reduced data analysis time significantly',
    ],
    images: [
      'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=1200&h=800&fit=crop',
      'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&h=800&fit=crop',
    ],
  },
  'linkedin-api': {
    title: 'LinkedIn API Integration',
    description: 'Built API connecting LinkedIn to company website for comprehensive ads management.',
    tags: ['Python', 'Django', 'HTML', 'JSON'],
    year: '2022',
    fullDescription: 'As a Software Programmer at LinkClicks, I developed an API that connects from LinkedIn to the company website as part of an all-inclusive ads manager. The system included user authorization, access token storage, and comprehensive LinkedIn ad campaign management.',
    challenge: 'Creating a seamless integration between LinkedIn\'s API and the LinkClicks platform while maintaining security and enabling full campaign management capabilities.',
    solution: 'Built a robust Python/Django-based API system with OAuth authorization, secure token storage in the company database, and comprehensive endpoints for creating and retrieving LinkedIn ad campaigns.',
    results: [
      'Successfully integrated LinkedIn API into ads management platform',
      'Enabled clients to manage LinkedIn campaigns from central dashboard',
      'Implemented secure OAuth authorization flow',
      'Streamlined campaign creation and monitoring process',
    ],
    images: [
      'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=1200&h=800&fit=crop',
      'https://images.unsplash.com/photo-1432888622747-4eb9a8f2c36c?w=1200&h=800&fit=crop',
    ],
  },
  'scarcity-marketing': {
    title: 'E-commerce Scarcity Feature',
    description: 'Implemented dynamic scarcity marketing on e-commerce platform to increase conversions.',
    tags: ['Javascript', 'HTML', 'CSS', 'Marketing'],
    year: '2022',
    fullDescription: 'As a Web Programmer at Werrv Inc., I incorporated scarcity marketing into the Werrv website by editing the product display quantity. I programmed this feature to activate only in certain situations (dependent on date, SKU, price, etc.) to ensure that any fluctuation in sales was a direct result of the scarcity marketing.',
    challenge: 'Implementing a scarcity marketing feature that would increase conversions without appearing manipulative, with precise control over when and how it activates.',
    solution: 'Developed a conditional scarcity system using Liquid, HTML, CSS, and JavaScript that dynamically adjusted product quantity displays based on multiple parameters including date, SKU, and price point.',
    results: [
      'Successfully implemented scarcity marketing across product catalog',
      'Enabled A/B testing through conditional activation',
      'Provided clear attribution of sales changes to scarcity feature',
      'Increased conversion rates on targeted products',
    ],
    images: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=800&fit=crop',
      'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=800&fit=crop',
    ],
  },
  'microfluidic-research': {
    title: 'Biomedical Research Publication',
    description: 'Co-authored scientific publication on microfluidic technologies for RNA-based virus diagnosis.',
    tags: ['Research', 'Biomedical', 'Writing'],
    year: '2022',
    fullDescription: 'As an Engineering Physics Research Assistant at McMaster University, I co-authored a scientific publication regarding on-site microfluidic technologies and their applications in diagnosing RNA-based viruses. I was also acknowledged for proofreading the "Diagnosis of SARS-CoV-2 using microfluidic technologies" section of a technical book chapter. Additionally, I aided in the research and design of a wearable biomedical device capable of stimulating acupuncture points using non-invasive energy waves.',
    challenge: 'Contributing to cutting-edge research on microfluidic diagnostic technologies while ensuring technical accuracy and clarity in scientific writing.',
    solution: 'Conducted comprehensive literature review and research on microfluidic technologies, collaborated with research team on scientific publication, and contributed to the development of novel wearable biomedical devices.',
    results: [
      'Co-authored peer-reviewed scientific publication',
      'Acknowledged in technical book chapter on COVID-19 diagnosis',
      'Contributed to wearable biomedical device design',
      'Advanced understanding of on-site diagnostic technologies',
    ],
    images: [
      'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=1200&h=800&fit=crop',
      'https://images.unsplash.com/photo-1576086213369-97a306d36557?w=1200&h=800&fit=crop',
    ],
  },
  'health-tech-research': {
    title: 'Health Technology Market Analysis',
    description: 'Performed market research on behavioral health technology and wearable biomedical devices.',
    tags: ['Market Research', 'Health Tech'],
    year: '2022',
    fullDescription: 'As a Health Technology Market Research Intern at Behaivior, I performed comprehensive market research and data analysis revolving around behavioral health technology stakeholders. I developed a profound understanding of the market for wearable biomedical devices and emerging health technology trends.',
    challenge: 'Analyzing the complex behavioral health technology market and identifying key stakeholders, trends, and opportunities in the wearable biomedical device sector.',
    solution: 'Conducted systematic market research using various data sources, performed competitive analysis, and synthesized findings into actionable insights for strategic decision-making.',
    results: [
      'Completed comprehensive market analysis of behavioral health tech sector',
      'Identified key market trends and stakeholder relationships',
      'Developed deep understanding of wearable biomedical device market',
      'Delivered actionable insights for business strategy',
    ],
    images: [
      'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1200&h=800&fit=crop',
      'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=1200&h=800&fit=crop',
    ],
  },
  'social-media-growth': {
    title: 'Digital Marketing Campaign',
    description: 'Grew social media presence by 1150% across all platforms for UK subdivision.',
    tags: ['Marketing', 'Social Media'],
    year: '2020',
    fullDescription: 'As a Digital Marketing Analyst Intern at Aleph Global Scrum Team, I established a social media presence for the United Kingdom subdivision of the company. I grew followers by over 1150% on all social media platforms including Facebook, Instagram, Twitter, and Pinterest. I also co-authored a writing piece titled "Digital Marketing Plan for Small Businesses" on the company blog.',
    challenge: 'Building a social media presence from scratch for a new market subdivision while creating engaging content that resonated with the UK audience.',
    solution: 'Developed and executed a comprehensive digital marketing strategy across multiple platforms, created targeted content for UK market, and implemented growth tactics to rapidly build follower base.',
    results: [
      'Achieved 1150% follower growth across all platforms',
      'Established brand presence in UK market',
      'Co-authored published article on digital marketing',
      'Successfully launched social media channels from zero',
    ],
    images: [
      'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=1200&h=800&fit=crop',
      'https://images.unsplash.com/photo-1432888622747-4eb9a8f2c36c?w=1200&h=800&fit=crop',
    ],
  },
};

export function CaseStudy() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [projectId]);

  const project = projectId ? projectData[projectId] : null;

  if (!project) {
    return (
      <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)] flex items-center justify-center">
        <StarField />
        <div className="relative z-10 text-center">
          <h1 className="text-4xl mb-8">Project not found</h1>
          <button
            onClick={() => navigate('/')}
            className="px-6 py-3 border border-[var(--border)] hover:border-[var(--glow-blue)] transition-colors"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <StarField />
      <CursorTrail />

      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-[var(--border)] bg-[#000000]">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back</span>
          </button>
          <div className="font-mono text-xs tracking-widest uppercase text-[var(--foreground)]">
            Case Study
          </div>
        </div>
      </nav>

      <div className="pt-32 pb-24">
        <SectionContainer>
          <div className="max-w-4xl mx-auto">
            <div className="mb-12">
              <div className="font-mono text-xs tracking-wider text-[var(--muted-foreground)] uppercase mb-4">
                {project.year}
              </div>
              <h1 className="text-5xl tracking-tight mb-6">{project.title}</h1>
              <p className="text-xl text-[var(--muted-foreground)] leading-relaxed mb-8">
                {project.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag, i) => (
                  <span
                    key={i}
                    className="px-4 py-2 text-xs font-mono tracking-wide border border-[var(--glow-blue)] text-[var(--glow-blue)]"
                    style={{ borderRadius: '2px' }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="mb-16">
              <ProjectCarousel images={project.images} />
            </div>

            <div className="space-y-16">
              <div>
                <h2 className="text-2xl tracking-tight mb-4">Overview</h2>
                <p className="text-[var(--muted-foreground)] leading-relaxed">
                  {project.fullDescription}
                </p>
              </div>

              <div>
                <h2 className="text-2xl tracking-tight mb-4">The Challenge</h2>
                <p className="text-[var(--muted-foreground)] leading-relaxed">
                  {project.challenge}
                </p>
              </div>

              <div>
                <h2 className="text-2xl tracking-tight mb-4">The Solution</h2>
                <p className="text-[var(--muted-foreground)] leading-relaxed">
                  {project.solution}
                </p>
              </div>

              <div>
                <h2 className="text-2xl tracking-tight mb-4">Results & Impact</h2>
                <ul className="space-y-3">
                  {project.results.map((result, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-[var(--glow-blue)] mt-2 flex-shrink-0" />
                      <span className="text-[var(--muted-foreground)] leading-relaxed">
                        {result}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mt-16 pt-16 border-t border-[var(--border)] text-center">
              <button
                onClick={() => navigate('/')}
                className="px-8 py-3 border border-[var(--border)] hover:border-[var(--glow-blue)] hover:text-[var(--glow-blue)] transition-all"
                style={{ borderRadius: '2px' }}
              >
                View More Projects
              </button>
            </div>
          </div>
        </SectionContainer>
      </div>
    </div>
  );
}
