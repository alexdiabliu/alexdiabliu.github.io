import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { StarField } from '../components/StarField';
import { SectionContainer } from '../components/SectionContainer';
import { CursorTrail } from '../components/CursorTrail';

export function AboutMe() {
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  const interests = [
    {
      title: 'Creative Technology',
      description: 'Exploring the intersection of art and engineering through generative systems, interactive installations, and experimental media.',
    },
    {
      title: 'Spatial Computing',
      description: 'Building immersive experiences for AR/VR platforms and researching new paradigms for spatial interfaces.',
    },
    {
      title: 'Generative Art',
      description: 'Creating algorithmic compositions that explore emergence, complexity, and aesthetic systems.',
    },
    {
      title: 'Music & Sound Design',
      description: 'Experimenting with audio synthesis, DSP algorithms, and the relationship between sound and visual expression.',
    },
    {
      title: 'Open Source',
      description: 'Contributing to and maintaining tools that empower creative communities and advance the state of digital expression.',
    },
    {
      title: 'Teaching & Mentorship',
      description: 'Sharing knowledge through workshops, talks, and collaborative projects with emerging technologists.',
    },
  ];

  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <StarField />
      <CursorTrail />

      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-[var(--border)] bg-[#000000]">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back</span>
          </button>
          <div className="font-mono text-xs tracking-widest uppercase text-[var(--foreground)]">
            About Me
          </div>
        </div>
      </nav>

      <div className="pt-32 pb-24">
        <SectionContainer>
          <div className="max-w-5xl mx-auto">
            <div className="mb-16 text-center">
              <h1 className="text-5xl tracking-tight mb-6">More About Me</h1>
              <p className="text-xl text-[var(--muted-foreground)] leading-relaxed max-w-3xl mx-auto">
                A multidisciplinary creative technologist passionate about building tools, experiences, and systems that live at the intersection of art, code, and design.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-16">
              <div
                className="border border-[var(--border)] p-8 bg-[var(--cosmos-panel)]"
                style={{ borderRadius: '2px' }}
              >
                <h2 className="text-2xl mb-6">Background</h2>
                <div className="space-y-4 text-[var(--muted-foreground)] leading-relaxed">
                  <p>
                    I started my journey in technology with a fascination for how code could create art. Over the years, this curiosity evolved into a career building creative tools, generative systems, and interactive experiences.
                  </p>
                  <p>
                    My work spans multiple disciplines — from real-time rendering engines to audio synthesis frameworks, from spatial computing interfaces to decentralized knowledge systems. What ties it all together is a belief that the best technology feels invisible, intuitive, and somehow inevitable.
                  </p>
                  <p>
                    I'm driven by questions about emergence, complexity, and the poetics of computation. How can algorithms create beauty? How can constraints foster creativity? What does it mean to design for discovery?
                  </p>
                </div>
              </div>

              <div
                className="border border-[var(--border)] p-8 bg-[var(--cosmos-panel)]"
                style={{ borderRadius: '2px' }}
              >
                <h2 className="text-2xl mb-6">Philosophy</h2>
                <div className="space-y-4 text-[var(--muted-foreground)] leading-relaxed">
                  <p>
                    I believe the most interesting work happens at intersections — where disciplines collide, where constraints inspire innovation, where accidents become features.
                  </p>
                  <p>
                    Technology should amplify human creativity, not replace it. The best tools get out of the way, empowering creators to focus on what matters: the work itself.
                  </p>
                  <p>
                    I'm committed to open source, collaborative creation, and sharing knowledge. The creative technology community thrives when we build in public and lift each other up.
                  </p>
                </div>
              </div>
            </div>

            <div className="mb-16">
              <h2 className="text-3xl tracking-tight mb-12 text-center">Multidisciplinary Interests</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {interests.map((interest, i) => (
                  <div
                    key={i}
                    className="border border-[var(--border)] p-6 bg-[var(--cosmos-panel)] hover:border-[var(--glow-blue)] transition-all duration-300"
                    style={{ borderRadius: '2px' }}
                  >
                    <h3 className="text-lg mb-3 text-[var(--foreground)]">{interest.title}</h3>
                    <p className="text-sm text-[var(--muted-foreground)] leading-relaxed">
                      {interest.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div
              className="border border-[var(--border)] p-8 bg-[var(--cosmos-panel)]"
              style={{ borderRadius: '2px' }}
            >
              <h2 className="text-2xl mb-6">Beyond The Screen</h2>
              <div className="space-y-4 text-[var(--muted-foreground)] leading-relaxed">
                <p>
                  When I'm not building digital experiences, you'll find me exploring the natural world, experimenting with analog synthesis, or diving into books about systems thinking, design philosophy, and the history of computation.
                </p>
                <p>
                  I'm particularly interested in how physical and digital experiences can inform each other — how the constraints of material tools can inspire digital workflows, and how computational thinking can enhance creative practice.
                </p>
                <p>
                  I believe in continuous learning, creative experimentation, and the value of making things that don't have to "make sense" — sometimes the most interesting discoveries happen when we give ourselves permission to play.
                </p>
              </div>
            </div>

            <div className="mt-16 pt-16 border-t border-[var(--border)] text-center">
              <h2 className="text-2xl mb-6">Let's Connect</h2>
              <p className="text-[var(--muted-foreground)] mb-8 max-w-2xl mx-auto">
                I'm always excited to collaborate on interesting projects, mentor emerging technologists, or just chat about creative technology over coffee.
              </p>
              <button
                onClick={() => navigate('/')}
                className="px-8 py-3 border border-[var(--border)] hover:border-[var(--glow-blue)] hover:text-[var(--glow-blue)] transition-all"
                style={{ borderRadius: '2px' }}
              >
                Back to Home
              </button>
            </div>
          </div>
        </SectionContainer>
      </div>
    </div>
  );
}
